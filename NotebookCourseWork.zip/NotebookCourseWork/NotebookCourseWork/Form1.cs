namespace NotebookCourseWork
{
    public partial class Form1 : Form
    {
        private ContactCollection contactCollection = new ContactCollection();
        private const string FileName = "contacts.json";

        public Form1()
        {
            InitializeComponent();

            contactCollection.Load(FileName);

            contactsGrid.AllowUserToAddRows = false;
            contactsGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            contactsGrid.MultiSelect = false;
            contactsGrid.ReadOnly = true;

            RefreshGrid();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ContactForm form = new ContactForm();

            if (form.ShowDialog() == DialogResult.OK && form.NewContact != null)
            {
                contactCollection.Add(form.NewContact);
                RefreshGrid();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (contactsGrid.SelectedRows.Count == 0)
            {
                MessageBox.Show("Оберіть контакт для редагування.");
                return;
            }

            object? selectedItem = contactsGrid.SelectedRows[0].DataBoundItem;

            if (selectedItem is not Contact selectedContact)
            {
                MessageBox.Show("Помилка вибору контакту.");
                return;
            }

            ContactForm form = new ContactForm(selectedContact);

            if (form.ShowDialog() == DialogResult.OK && form.NewContact != null)
            {
                contactCollection.Edit(selectedContact, form.NewContact);
                RefreshGrid();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (contactsGrid.SelectedRows.Count == 0)
            {
                MessageBox.Show("Оберіть контакт для видалення.");
                return;
            }

            object? selectedItem = contactsGrid.SelectedRows[0].DataBoundItem;

            if (selectedItem is not Contact selectedContact)
            {
                MessageBox.Show("Оберіть контакт для видалення.");
                return;
            }

            DialogResult result = MessageBox.Show(
                "Ви дійсно хочете видалити вибраний контакт?",
                "Підтвердження видалення",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                contactCollection.Remove(selectedContact);
                RefreshGrid();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string searchText = textBox1.Text.ToLower();

            List<Contact> contactsToSave;

            if (string.IsNullOrWhiteSpace(searchText))
            {
                contactsToSave = contactCollection.Contacts.ToList();
            }
            else
            {
                contactsToSave = contactCollection.Search(searchText);
            }

            if (contactsToSave.Count == 0)
            {
                MessageBox.Show("Немає контактів для збереження.");
                return;
            }

            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "JSON files (*.json)|*.json";
            saveFileDialog.FileName = string.IsNullOrWhiteSpace(searchText)
                ? "contacts.json"
                : "filtered_contacts.json";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                contactCollection.Save(saveFileDialog.FileName, contactsToSave);
                MessageBox.Show("Контакти успішно збережено.");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            List<Contact> birthdayContacts = contactCollection.GetBirthdayContacts();

            if (birthdayContacts.Count == 0)
            {
                MessageBox.Show("Сьогодні немає контактів з днем народження.");
                return;
            }

            string message = "Сьогодні день народження у:\n\n";

            foreach (Contact contact in birthdayContacts)
            {
                message += $"{contact.Name}\n";
                message += $"Привітання: Вітаю з днем народження, {contact.Name}! Бажаю здоров’я, щастя та успіхів!\n\n";
            }

            MessageBox.Show(message, "Привітання з днем народження");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            contactCollection.SortByName();
            RefreshGrid();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            contactCollection.SortByLastEditDate();
            RefreshGrid();
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "JSON files (*.json)|*.json";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                contactCollection.Load(openFileDialog.FileName);
                textBox1.Clear();
                RefreshGrid();

                MessageBox.Show("Контакти успішно завантажено.");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string searchText = textBox1.Text.ToLower();

            if (string.IsNullOrWhiteSpace(searchText))
            {
                contactsGrid.DataSource = contactCollection.Contacts;
                contactsGrid.ClearSelection();
                SetColumnHeaders();
                return;
            }

            List<Contact> filteredContacts = contactCollection.Search(searchText);

            contactsGrid.DataSource = filteredContacts;
            contactsGrid.ClearSelection();
            SetColumnHeaders();
        }

        private void RefreshGrid()
        {
            contactsGrid.DataSource = contactCollection.Contacts;
            contactsGrid.ClearSelection();
            SetColumnHeaders();
        }

        private void SetColumnHeaders()
        {
            foreach (DataGridViewColumn column in contactsGrid.Columns)
            {
                if (column.Name == "Name")
                    column.HeaderText = "ПІБ";

                if (column.Name == "Phone")
                    column.HeaderText = "Телефон";

                if (column.Name == "Address")
                    column.HeaderText = "Адреса";

                if (column.Name == "Birthday")
                    column.HeaderText = "Дата народження";

                if (column.Name == "WorkPlace")
                    column.HeaderText = "Місце роботи";

                if (column.Name == "Position")
                    column.HeaderText = "Посада";

                if (column.Name == "Notes")
                    column.HeaderText = "Нотатки";

                if (column.Name == "LastEditDate")
                    column.HeaderText = "Дата редагування";
            }

            contactsGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }
    }
}