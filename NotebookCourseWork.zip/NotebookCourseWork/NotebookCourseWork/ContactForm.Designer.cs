﻿namespace NotebookCourseWork
{
    partial class ContactForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            nameTextBox = new TextBox();
            phoneTextBox = new TextBox();
            addressTextBox = new TextBox();
            workPlaceTextBox = new TextBox();
            positionTextBox = new TextBox();
            notesTextBox = new TextBox();
            button1 = new Button();
            button2 = new Button();
            birthdayPicker = new DateTimePicker();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(194, 56);
            label1.Name = "label1";
            label1.Size = new Size(29, 15);
            label1.TabIndex = 0;
            label1.Text = "ПІБ:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(168, 97);
            label2.Name = "label2";
            label2.Size = new Size(58, 15);
            label2.TabIndex = 1;
            label2.Text = "Телефон:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(174, 135);
            label3.Name = "label3";
            label3.Size = new Size(52, 15);
            label3.TabIndex = 2;
            label3.Text = "Адреса: ";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(117, 179);
            label4.Name = "label4";
            label4.Size = new Size(106, 15);
            label4.TabIndex = 3;
            label4.Text = "Дата народження:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(80, 211);
            label5.Name = "label5";
            label5.Size = new Size(143, 15);
            label5.TabIndex = 4;
            label5.Text = "Місце роботи/навчання:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(173, 254);
            label6.Name = "label6";
            label6.Size = new Size(50, 15);
            label6.TabIndex = 5;
            label6.Text = "Посада:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(168, 296);
            label7.Name = "label7";
            label7.Size = new Size(55, 15);
            label7.TabIndex = 6;
            label7.Text = "Нотатки:";
            // 
            // nameTextBox
            // 
            nameTextBox.Location = new Point(237, 48);
            nameTextBox.Name = "nameTextBox";
            nameTextBox.Size = new Size(100, 23);
            nameTextBox.TabIndex = 7;
            // 
            // phoneTextBox
            // 
            phoneTextBox.Location = new Point(237, 89);
            phoneTextBox.Name = "phoneTextBox";
            phoneTextBox.Size = new Size(100, 23);
            phoneTextBox.TabIndex = 8;
            // 
            // addressTextBox
            // 
            addressTextBox.Location = new Point(237, 127);
            addressTextBox.Name = "addressTextBox";
            addressTextBox.Size = new Size(100, 23);
            addressTextBox.TabIndex = 9;
            // 
            // workPlaceTextBox
            // 
            workPlaceTextBox.Location = new Point(237, 208);
            workPlaceTextBox.Name = "workPlaceTextBox";
            workPlaceTextBox.Size = new Size(100, 23);
            workPlaceTextBox.TabIndex = 11;
            // 
            // positionTextBox
            // 
            positionTextBox.Location = new Point(237, 246);
            positionTextBox.Name = "positionTextBox";
            positionTextBox.Size = new Size(100, 23);
            positionTextBox.TabIndex = 12;
            // 
            // notesTextBox
            // 
            notesTextBox.Location = new Point(237, 288);
            notesTextBox.Name = "notesTextBox";
            notesTextBox.Size = new Size(100, 23);
            notesTextBox.TabIndex = 13;
            // 
            // button1
            // 
            button1.Location = new Point(168, 339);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 14;
            button1.Text = "OK";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(262, 339);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 15;
            button2.Text = "Скасувати";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // birthdayPicker
            // 
            birthdayPicker.Location = new Point(237, 173);
            birthdayPicker.Name = "birthdayPicker";
            birthdayPicker.Size = new Size(200, 23);
            birthdayPicker.TabIndex = 16;
            // 
            // ContactForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(birthdayPicker);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(notesTextBox);
            Controls.Add(positionTextBox);
            Controls.Add(workPlaceTextBox);
            Controls.Add(addressTextBox);
            Controls.Add(phoneTextBox);
            Controls.Add(nameTextBox);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "ContactForm";
            Text = "ContactForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private TextBox nameTextBox;
        private TextBox phoneTextBox;
        private TextBox addressTextBox;
        private TextBox workPlaceTextBox;
        private TextBox positionTextBox;
        private TextBox notesTextBox;
        private Button button1;
        private Button button2;
        private DateTimePicker birthdayPicker;
    }
}