﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace NotebookCourseWork
{
    public partial class ContactForm : Form
    {
        public Contact? NewContact { get; private set; }
        public ContactForm()
        {
            InitializeComponent();
        }
        public ContactForm(Contact contact)
        {
            InitializeComponent();

            nameTextBox.Text = contact.Name;
            phoneTextBox.Text = contact.Phone;
            addressTextBox.Text = contact.Address;
            birthdayPicker.Value = contact.Birthday;
            workPlaceTextBox.Text = contact.WorkPlace;
            positionTextBox.Text = contact.Position;
            notesTextBox.Text = contact.Notes;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(nameTextBox.Text))
            {
                MessageBox.Show("Введіть ПІБ.");
                return;
            }
            NewContact = new Contact
            {
                Name = nameTextBox.Text,
                Phone = phoneTextBox.Text,
                Address = addressTextBox.Text,
                Birthday = birthdayPicker.Value,
                WorkPlace = workPlaceTextBox.Text,
                Position = positionTextBox.Text,
                Notes = notesTextBox.Text,
                LastEditDate = DateTime.Now
            };

            DialogResult = DialogResult.OK;
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
