﻿using System;

namespace NotebookCourseWork
{
    public class Contact
    {
        public string Name { get; set; } = "";
        public string Phone { get; set; } = "";
        public string Address { get; set; } = "";
        public DateTime Birthday { get; set; }
        public string WorkPlace { get; set; } = "";
        public string Position { get; set; } = "";
        public string Notes { get; set; } = "";
        public DateTime LastEditDate { get; set; }

        public Contact()
        {
            Birthday = DateTime.Today;
            LastEditDate = DateTime.Now;
        }

        public override string ToString()
        {
            return $"{Name} - {Phone}";
        }
    }
}