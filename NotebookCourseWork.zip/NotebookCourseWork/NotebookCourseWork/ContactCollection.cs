﻿using System.ComponentModel;
using System.Text.Json;

namespace NotebookCourseWork
{
    public class ContactCollection
    {
        public BindingList<Contact> Contacts { get; private set; } = new BindingList<Contact>();

        public void Add(Contact contact)
        {
            Contacts.Add(contact);
        }

        public void Remove(Contact contact)
        {
            Contacts.Remove(contact);
        }

        public void Edit(Contact oldContact, Contact newContact)
        {
            int index = Contacts.IndexOf(oldContact);

            if (index >= 0)
            {
                Contacts[index] = newContact;
            }
        }

        public List<Contact> Search(string searchText)
        {
            searchText = searchText.ToLower();

            return Contacts.Where(contact =>
                contact.Name.ToLower().Contains(searchText) ||
                contact.Phone.ToLower().Contains(searchText) ||
                contact.Address.ToLower().Contains(searchText) ||
                contact.WorkPlace.ToLower().Contains(searchText) ||
                contact.Position.ToLower().Contains(searchText) ||
                contact.Notes.ToLower().Contains(searchText)
            ).ToList();
        }

        public void SortByName()
        {
            Contacts = new BindingList<Contact>(
                Contacts.OrderBy(contact => contact.Name).ToList());
        }

        public void SortByLastEditDate()
        {
            Contacts = new BindingList<Contact>(
                Contacts.OrderByDescending(contact => contact.LastEditDate).ToList());
        }

        public void Save(string fileName, List<Contact>? contactsToSave = null)
        {
            var data = contactsToSave ?? Contacts.ToList();

            string json = JsonSerializer.Serialize(data, new JsonSerializerOptions
            {
                WriteIndented = true,
                Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
            });

            File.WriteAllText(fileName, json);
        }

        public void Load(string fileName)
        {
            if (!File.Exists(fileName))
            {
                return;
            }

            string json = File.ReadAllText(fileName);

            List<Contact>? loadedContacts =
                JsonSerializer.Deserialize<List<Contact>>(json);

            if (loadedContacts != null)
            {
                Contacts = new BindingList<Contact>(loadedContacts);
            }
        }

        public List<Contact> GetBirthdayContacts()
        {
            DateTime today = DateTime.Today;

            return Contacts.Where(contact =>
                contact.Birthday.Day == today.Day &&
                contact.Birthday.Month == today.Month
            ).ToList();
        }
    }
}